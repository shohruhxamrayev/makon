Makon template: midnight-lounge
Photos and films rendered from the room's real plan.
Open it in Makon: https://makon-khaki.vercel.app/room.html?id=midnight-lounge
