Makon template: obsidian-lounge
Photos and films rendered from the room's real plan.
Open it: https://makon-khaki.vercel.app/room.html?id=obsidian-lounge
