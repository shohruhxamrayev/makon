Makon template: sage-kids
Photos and film rendered from the room's real plan.
Open it in Makon: https://makon-khaki.vercel.app/studio.html?template=sage-kids
