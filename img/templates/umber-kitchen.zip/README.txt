Makon template: umber-kitchen
Photos and films rendered from the room's real plan.
Open it: https://makon-khaki.vercel.app/room.html?id=umber-kitchen
